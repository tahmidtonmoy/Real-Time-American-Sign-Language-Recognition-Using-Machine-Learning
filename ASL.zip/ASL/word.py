import pickle
import cv2
import mediapipe as mp
import numpy as np
from collections import deque
import time

model_dict = pickle.load(open('./best_model.p', 'rb'))
model = model_dict['model']

cap = cv2.VideoCapture(0)

mp_hands = mp.solutions.hands
mp_drawing = mp.solutions.drawing_utils
mp_drawing_styles = mp.solutions.drawing_styles

hands = mp_hands.Hands(static_image_mode=True, min_detection_confidence=0.3)

labels_dict = {0: 'A', 1: 'B', 2: 'C', 3: 'D', 4: 'E', 5: 'F', 6: 'G', 7: 'H', 8: 'I', 9: 'J', 10: 'K', 11: 'L',
               12: 'M', 13: 'N', 14: 'O', 15: 'P', 16: 'Q', 17: 'R', 18: 'S', 19: 'T', 20: 'U', 21: 'V', 22: 'W',
               23: 'X', 24: 'Y', 25: 'Z', 26: '<', 27: ' '}

buffer_size = 10
prediction_buffer = deque(maxlen=buffer_size)
stability_duration = 2  # in seconds
start_time = None

predicted_word = ""
word_printed = False  # Flag to indicate if a word has been printed

last_deletion_time = 0
deletion_delay = 2  # Delay in seconds between successive deletions

while True:

    data_aux = np.zeros((84,))  # Update the size of data_aux array
    x_ = []
    y_ = []

    ret, frame = cap.read()

    H, W, _ = frame.shape

    frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    results = hands.process(frame_rgb)
    if results.multi_hand_landmarks:
        for hand_landmarks in results.multi_hand_landmarks:
            mp_drawing.draw_landmarks(
                frame,
                hand_landmarks,
                mp_hands.HAND_CONNECTIONS,
                mp_drawing_styles.get_default_hand_landmarks_style(),
                mp_drawing_styles.get_default_hand_connections_style())

        for hand_landmarks in results.multi_hand_landmarks:
            for i in range(len(hand_landmarks.landmark)):
                x = hand_landmarks.landmark[i].x
                y = hand_landmarks.landmark[i].y

                x_.append(x)
                y_.append(y)

            for i in range(len(hand_landmarks.landmark)):
                x = hand_landmarks.landmark[i].x
                y = hand_landmarks.landmark[i].y
                data_aux[2 * i] = x - min(x_)
                data_aux[2 * i + 1] = y - min(y_)

        # Calculate differences between consecutive x and y coordinates
        for i in range(len(x_) - 1):
            data_aux[2 * len(hand_landmarks.landmark) + i] = x_[i + 1] - x_[i]
            data_aux[2 * len(hand_landmarks.landmark) + i + 1] = y_[i + 1] - y_[i]

        x1 = int(min(x_) * W) - 10
        y1 = int(min(y_) * H) - 10

        x2 = int(max(x_) * W) - 10
        y2 = int(max(y_) * H) - 10

        prediction = model.predict([data_aux])  # Remove np.asarray() as data_aux is already a numpy array

        predicted_character = labels_dict[int(prediction[0])]

        prediction_buffer.append(predicted_character)

        if len(set(prediction_buffer)) == 1 and len(prediction_buffer) == buffer_size:
            if start_time is None:
                start_time = time.time()
            elif time.time() - start_time >= stability_duration:
                cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 0, 0), 4)
                cv2.putText(frame, predicted_character, (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 1.3, (0, 0, 0), 3,
                            cv2.LINE_AA)

                if predicted_character == '<':  # Check if the predicted character is '<'
                    current_time = time.time()
                    if current_time - last_deletion_time > deletion_delay:
                        if len(predicted_word) > 0:
                            predicted_word = predicted_word[:-1]  # Delete the last character from the predicted word
                            word_printed = False  # Reset word_printed flag after deletion
                            print("Word after deletion:", predicted_word)  # Print the current state of the predicted word
                            last_deletion_time = current_time

                elif predicted_character != ' ' and (not predicted_word or predicted_character != predicted_word[-1]):
                    predicted_word += predicted_character
                    word_printed = False

                elif predicted_character == ' ' and not word_printed:
                    print("Predicted Word:", predicted_word)
                    predicted_word = ""
                    word_printed = True

    cv2.imshow('frame', frame)
    if cv2.waitKey(5) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()