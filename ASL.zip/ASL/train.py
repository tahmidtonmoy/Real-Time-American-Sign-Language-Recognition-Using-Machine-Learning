import pickle
import numpy as np
from tensorflow.keras.preprocessing.sequence import pad_sequences
from sklearn.ensemble import RandomForestClassifier, BaggingClassifier, ExtraTreesClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

# Load data
with open('./data.pickle', 'rb') as f:
    data_dict = pickle.load(f)

data = data_dict['data']
max_len = max([len(seq) for seq in data])  # Get the maximum sequence length
data = pad_sequences(data, maxlen=max_len, padding='post', dtype='float32')  # Pad the sequences with zeros

labels = np.asarray(data_dict['labels'])
x_train, x_test, y_train, y_test = train_test_split(data, labels, test_size=0.2, shuffle=True, stratify=labels)

# Define classifiers
classifiers = {
    'Random Forest': RandomForestClassifier(),
    'Logistic Regression': LogisticRegression(),
    'MLP Classifier': MLPClassifier(),
    'K Neighbors Classifier': KNeighborsClassifier(),
    'Decision Tree Classifier': DecisionTreeClassifier(),
    'Bagging Classifier': BaggingClassifier(),
    'Extra Trees Classifier': ExtraTreesClassifier()
}

best_score = 0
best_model = None
best_classifier_name = None

# Train and evaluate each classifier
for name, clf in classifiers.items():
    clf.fit(x_train, y_train)
    y_predict = clf.predict(x_test)
    score = accuracy_score(y_predict, y_test)
    print('{} Accuracy: {}%'.format(name, score * 100))

    # Update best model if current classifier has higher accuracy
    if score > best_score:
        best_score = score
        best_model = clf
        best_classifier_name = name

print('Best Classifier: {}, Accuracy: {}%'.format(best_classifier_name, best_score * 100))

# Save the best model
with open('best_model.p', 'wb') as f:
    pickle.dump({'model': best_model}, f)

